window.onload = async function(){

  /* ============================
   Aggionamento del menu
============================ */

async function getProfile() {
  try {
    const resp = await fetch("/api/profile", { credentials: "same-origin" });
    if (!resp.ok) return null;
    const body = await resp.json();
    return body.user || null;
  } catch (e) {
    console.error("Erreur getProfile:", e);
    return null;
  }
}
  const linkConnexion = document.getElementById("link-connexion");
  const btnLogout = document.getElementById("logout-link");

  const user = await getProfile();
  if (user) {
      linkConnexion.style.display = "none";
      btnLogout.style.display = "inline-block";
      btnLogout.onclick = async () => {
        await fetch("/logout", { method: "POST" });
        window.location.reload();
      }
    console.log("Connecté en tant que:", user.nome);
  } else {
    alert("Devi aver effettuato l'accesso per accedere a questa pagina.");
    window.location.href = "connexion.html";
  }





/* ============================
   1. script
============================ */


const form = document.getElementById("citationForm");
form.addEventListener("submit", async function(e) {
  e.preventDefault();

  const data = {
    nom: document.getElementById("nom").value,
    citation: document.getElementById("citation").value,
    auteur: document.getElementById("auteur").value,
    theme: document.getElementById("theme").value
  };

  try {
    const res = await fetch("/send-citation", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });

    const result = await res.json();
    alert(result.message);

    this.style.display = "none";
    document.getElementById("confirmation").style.display= "block";
  } catch (err) {
    alert("Erreur nell'invio del messaggio");
    console.error(err);
  }
});
  
}




