
window.onload = async function(){

  /* ============================
   Aggionamento del menu
============================ */

    async function getProfile() {
  try {
    const resp = await fetch("/api/profile", { credentials: "same-origin" });
    if (!resp.ok) return null;
    const body = await resp.json();
    return body.user || null;
  } catch (e) {
    console.error("Erreur getProfile:", e);
    return null;
  }
}

  const linkConnexion = document.getElementById("link-connexion");
  const btnLogout = document.getElementById("logout-link");

  const user = await getProfile();
      if (user) {
      linkConnexion.style.display = "none";
      btnLogout.style.display = "inline-block";
      btnLogout.onclick = async () => {
        await fetch("/logout", { method: "POST" });
        window.location.reload();
    }
    console.log("Connecté en tant que:", user.nome);  //  verifico che user.id esiste
  }




  const panierModal = document.getElementById("panierModal");
  const contenuPanier = document.getElementById("contenuPanier");
  const totalPanier = document.getElementById("totalPanier");
  const voirPanierBtn = document.getElementById("voirPanier");
  const fermerPanierBtn = document.getElementById("fermerPanier");
  const acheterBtn = document.getElementById("acheterBtn");

  
  // Carica i libri disponibili

  try {
    const res = await fetch("/api/livres");
    if (!res.ok) throw new Error("Error nel caricamento dei libri");
    const livres = await res.json();

    const boutiqueDiv = document.getElementById("boutique");
    boutiqueDiv.innerHTML = ""; 

    for (const l of livres) {

      const livreDiv = document.createElement("div");
      livreDiv.className = "livre";

      // Immagine
      const img = document.createElement("img");
      img.src = `style/immagini/personnaggi/${l.id}.jpg`;
      img.alt = l.titre;

      // Titolo
      const titre = document.createElement("h3");
      titre.textContent = l.titre;

      // Autore
      const auteur = document.createElement("p");
      auteur.textContent = "Auteur : " + l.auteur;

      // Prezzo
      const prix = document.createElement("p");
      prix.textContent = "Prix : " + l.prix + " €";

      // Quantità
      const quantità = document.createElement("p");
      quantità.textContent = "Disponibilité : " + l.stock ;

      // Bouton "Ajouter au panier"
      const bouton = document.createElement("button");
      bouton.textContent = "Ajouter au panier";
      bouton.type = "button";

bouton.addEventListener("click", async() => {
    if (!user) {
 alert("Devi aver effettuato l'accesso per accedere a questa pagina.");
    window.location.href = "connexion.html";
    }

    try {
    const res = await fetch(`/api/panier/${l.id}`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ utilisateurId: user.id })
});

    const data = await res.json();
    if (!res.ok) {
  // Non continuare se c'è un errore (stock 0, etc.)
  alert(data.message);
  return;
}
alert(data.message);
  } catch (err) {
    console.error("Erreur :", err);
  }
});

      livreDiv.appendChild(img);
      livreDiv.appendChild(titre);
      livreDiv.appendChild(auteur);
      livreDiv.appendChild(prix);
      livreDiv.appendChild(quantità);
      livreDiv.appendChild(bouton);
      boutiqueDiv.appendChild(livreDiv);
    }

    if (livres.length === 0) {
      const msg = document.createElement("div");
      msg.textContent = "Nessun libro disponibile al momento.";
      msg.style.padding = "1em";
      msg.style.color = "#666";
      boutiqueDiv.appendChild(msg);
    }

  } catch (e) {
    console.error("Erreur :", e);
    const boutiqueDiv = document.getElementById("boutique");
    boutiqueDiv.innerHTML = "<p>Errore durante il caricamento dei libri.</p>";
  }


  // Apre la modalità carrello
  voirPanierBtn.addEventListener("click", async () => {
      if (!user) {
 alert("Devi aver effettuato l'accesso per accedere a questa pagina.");
    window.location.href = "connexion.html";
    }

    await afficherPanier();
    panierModal.classList.remove("hidden");
  });

  // Chiude la modalità carrello
  fermerPanierBtn.addEventListener("click", () => {
    panierModal.classList.add("hidden");
    window.location.reload();
  });



  // Acquistare
acheterBtn.addEventListener("click", async () => {
  try {
    // Recupera il carrello corrente dalla db
    const resPanier = await fetch(`/api/panier?utilisateurId=${user.id}`, {
      credentials: "include"
    });
    const panier = await resPanier.json();

    if (!panier.length) {
      alert("Il tuo carrello è vuoto !");
      return;
    }
console.log("Carrello recuperato:", panier);

    // Compra ogni libro del carrello individualmente
    for (const l of panier) {
  const livreId = l.livre_id || l.livreId || l.id; 
  const quantite = l.quantite;
  const livreTitre = l.titre;
  const res = await fetch(`/api/achat/${livreId}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ utilisateurId: user.id, quantite: quantite, livreTitre: livreTitre})
  });
      const data = await res.json();
      alert(data.message);
      if (!res.ok) {
        console.error("Error acquisto:", data.message);
      } else {
        console.log(`✅ Livre ${l.livre_id} acquistato con successo`);
      }
    
await fetch(`/api/panier/${l.panier_id}`, {
  method: "DELETE",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ utilisateurId: user.id })
}); }

    afficherPanier();

  } catch (err) {
    console.error("Error durante l'acquisto :", err);
    alert("Errore durante l'acquisto. Riprova più tardi.");
  }
});





  // Funzione per visualizzare il carrello della spesa
  async function afficherPanier() {
       const res = await fetch(`/api/panier?utilisateurId=${user.id}`);
    if (!res.ok) {
      contenuPanier.innerHTML = "<p>Error durante il caricamento del carrello.</p>";
      return;
    }

    const livres = await res.json();
    if (livres.length === 0) {
      contenuPanier.innerHTML = "<p>Il tuo carrello è vuoto.</p>";
      totalPanier.textContent = "";
      return;
    }

    let total = 0;
    contenuPanier.innerHTML = livres.map(l => {
      const prixTotal = l.prix * l.quantite;
      total += prixTotal;
      return `
        <div class="livre-panier">
          <h4>${l.titre}</h4>
          <p>Prix unitaire : ${l.prix} €</p>
          <label>Quantité :
            <input type="number" min="1" value="${l.quantite}" onchange="modifierQuantite(${l.panier_id}, this.value)">
          </label>
          <p>Total : ${prixTotal.toFixed(2)} €</p>
          <button onclick="supprimerDuPanier(${l.panier_id})">Supprimer</button>
        </div>
      `;
    }).join("");

    totalPanier.textContent = `Total à payer : ${total.toFixed(2)} €`;
  }

// Funzione globale: modifica la quantità
window.modifierQuantite = async (panier_id, quantite) => {
  try {
    const res = await fetch(`/api/panier/${panier_id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ quantite: parseInt(quantite) }),
      credentials: "include"
    });
    const resp = await res.json();
    alert(resp.message);
    await afficherPanier(); // aggiornare il carrello
  } catch (err) {
    console.error("Error durante la modificazione :", err);
  }
}

// Funzione globale: rimuovere un libro dal carrello
window.supprimerDuPanier = async (panier_id) => {
  try {
    await fetch(`/api/panier/${panier_id}`, {
      method: "DELETE",
      credentials: "include"
    });
    await afficherPanier(); 
  } catch (err) {
    console.error("Error durante la cancellazione :", err);
  }
}

  }
