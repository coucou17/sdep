window.onload = async function(){


  /* ============================
   Aggionamento del menu
============================ */

    async function getProfile() {
  try {
    const resp = await fetch("/api/profile", { credentials: "same-origin" });
    if (!resp.ok) return null;
    const body = await resp.json();
    return body.user || null;
  } catch (e) {
    console.error("Erreur getProfile:", e);
    return null;
  }
}

  const linkConnexion = document.getElementById("link-connexion");
  const btnLogout = document.getElementById("logout-link");

  const user = await getProfile();
      if (user) {
      linkConnexion.style.display = "none";
      btnLogout.style.display = "inline-block";
      btnLogout.onclick = async () => {
        await fetch("/logout", { method: "POST" });
        window.location.reload();
    }
    console.log("Connecté en tant que:", user.nome);  //  verifico che user.id esiste
  }  else {
 alert("Devi aver effettuato l'accesso per accedere a questa pagina.");
    window.location.href = "connexion.html";
    }





  try {
    const res = await fetch("/api/dashboard", { credentials: "include" });
    const data = await res.json();

    const contenuto = document.getElementById("contenuto-dashboard");

    if (!res.ok) {
      contenuto.innerHTML = `<p>${data.message || "Errore durante il caricamento"}</p>`;
      return;
    }

    if (data.acquisti.length === 0) {
      contenuto.innerHTML = `<p>Non hai ancora effettuato acquisti.</p>`;
      return;
    }

    contenuto.innerHTML = `
      <h2> Storico completo</h2>
      ${data.acquisti.map(a => `
        <div class="acquisto">
          <h3>${a.titre}</h3>
          <p>Quantità: ${a.quantite}</p>
          <p>Prezzo unitario: €${a.prix}</p>
          <p>Data: ${new Date(a.date_achat).toLocaleString()}</p>
        </div>
      `).join("")}
    `;
  } catch (err) {
    console.error(err);
    document.getElementById("contenuto-dashboard").innerHTML =
      "<p>Errore di connessione al server</p>";
  }
}
