window.onload = async function(){
  

  /* ============================
   Aggionamento del menu
============================ */
  async function getProfile() {
  try {
    const resp = await fetch("/api/profile", { credentials: "same-origin" });
    if (!resp.ok) return null;
    const body = await resp.json();
    return body.user || null;
  } catch (e) {
    console.error("Erreur getProfile:", e);
    return null;
  }
}



  const linkConnexion = document.getElementById("link-connexion");
  const btnLogout = document.getElementById("logout-link");

  const user = await getProfile();
    if(!user) {
      btnLogout.style.display = "none";
      linkConnexion.style.display = "inline";
  } 
    else {
      linkConnexion.style.display = "none";
      btnLogout.style.display = "inline-block";
      btnLogout.onclick = async () => {
        await fetch("/logout", { method: "POST" });
        window.location.reload();
      };
    console.log("Connecté en tant que:", user.nome);
  }




  // Lista delle pagine del libro
  const pages = [
    "style/immagini/libro/1.jpg",
    "style/immagini/libro/2.jpg",
    "style/immagini/libro/3.jpg",
    "style/immagini/libro/4.jpg",
    "style/immagini/libro/5.jpg",
    "style/immagini/libro/6.jpg",
    "style/immagini/libro/7.jpg",
    "style/immagini/libro/8.jpg",
    "style/immagini/libro/9.jpg",
    "style/immagini/libro/10.jpg",
    "style/immagini/libro/11.jpg"
  ];

  let currentPage = 0;
  const pageImage = document.getElementById("pageImage");
  const prevBtn = document.getElementById("prevBtn");
  const nextBtn = document.getElementById("nextBtn");

  function updatePage() {
    pageImage.src = pages[currentPage];
    prevBtn.disabled = currentPage === 0;
    nextBtn.disabled = currentPage === pages.length - 1;
  }

  prevBtn.addEventListener("click", () => {
    if (currentPage > 0) {
      currentPage--;
      updatePage();
    }
  });

  nextBtn.addEventListener("click", () => {
    if (currentPage < pages.length - 1) {
      currentPage++;
      updatePage();
    }
  });

  // Inizializzo la stampa
  updatePage();

 }